import React from "react";
import { MdLanguage } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";

const Navbar: React.FC = () => {
  return (
    <nav className="hidden  fixed top-0 left-0 right-0 z-10 md:flex justify-between items-center py-4 px-8 bg-white">
      <div className="flex items-center space-x-4 w-full">
        <a href="#" className="text-customLightBlue font-bold text-4xl">
          NEXT
        </a>
        <div className="flex-grow flex justify-center space-x-6">
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            Coverage
          </a>
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            Who We Insure
          </a>
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            Certificate
          </a>
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            Partner
          </a>
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            Support
          </a>
          <a href="#" className="text-gray-900 text-lg hover:text-customBlue">
            About Us
          </a>
          <a href="#" className="flex items-center gap-1 text-gray-900">
            <MdLanguage /> ES
          </a>
          <a
            href="#"
            className="text-gray-700 border border-gray-900 rounded-full px-4 py-1 transition duration-300 hover:bg-black hover:text-white"
          >
            Login
          </a>
          <a
            href="#"
            className="bg-customBlue transition-all text-white rounded-full px-4 py-1 hover:bg-customLightBlue"
          >
            Get Instant Quote
          </a>
          <a href="#" className="text-customLightBlue">
            <IoSearchOutline />
          </a>
        </div>
        <div className="flex items-center space-x-4">
          
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
